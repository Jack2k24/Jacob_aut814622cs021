package com.shankarlohar.flashnews.models

data class ApiKey(val key: String)