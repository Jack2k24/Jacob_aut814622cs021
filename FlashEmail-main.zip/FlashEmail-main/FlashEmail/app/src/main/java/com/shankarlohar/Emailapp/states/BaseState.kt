package com.shankarlohar.flashnews.states

interface BaseState